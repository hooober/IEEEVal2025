#ifndef HEART_RAINBOW_H_
#define HEART_RAINBOW_H_

/* coordinate stuff */
typedef struct {
  uint8_t x;
  uint8_t y;
} coord_t;

#endif